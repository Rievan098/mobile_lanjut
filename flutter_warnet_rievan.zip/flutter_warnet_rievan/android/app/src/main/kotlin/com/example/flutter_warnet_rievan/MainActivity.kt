package com.example.flutter_warnet_rievan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
